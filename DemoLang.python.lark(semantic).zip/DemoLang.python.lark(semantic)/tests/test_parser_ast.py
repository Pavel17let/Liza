from compiler.ast import (
    AssignNode,
    BinOp,
    BinOpNode,
    BreakNode,
    CallNode,
    ConstDeclNode,
    ContinueNode,
    ForNode,
    FuncNode,
    IfNode,
    IncDecNode,
    LetDeclNode,
    ReturnNode,
    StmtListNode,
)
from compiler.ast_printer import AstPrinter
from compiler.parser import parse


def test_typescript_declarations_and_call_expression():
    tree = parse(
        """
        let count: number = 1 + 2 * 3;
        const label: string = "total";
        print(count, label);
        """
    )

    let_decl, const_decl, call = tree.stmts

    assert isinstance(let_decl, LetDeclNode)
    binding = let_decl.bindings[0]
    assert binding.name == "count"
    assert binding.type_ann.desc == "number"
    assert isinstance(binding.init, BinOpNode)
    assert binding.init.op == BinOp.ADD
    assert binding.init.arg2.op == BinOp.MUL

    assert isinstance(const_decl, ConstDeclNode)
    assert const_decl.bindings[0].name == "label"
    assert const_decl.bindings[0].type_ann.desc == "string"
    assert const_decl.bindings[0].init.value == "total"

    assert isinstance(call, CallNode)
    assert call.name.name == "print"
    assert [arg.name for arg in call.params] == ["count", "label"]


def test_function_ast_keeps_parameters_return_type_and_body():
    tree = parse(
        """
        function add(a: number, b: number): number {
          return a + b;
        }
        """
    )

    func = tree.stmts[0]

    assert isinstance(func, FuncNode)
    assert func.name == "add"
    assert func.return_type.desc == "number"
    assert [(param.name, param.type_ann.desc) for param in func.params] == [
        ("a", "number"),
        ("b", "number"),
    ]
    assert isinstance(func.body, StmtListNode)
    assert isinstance(func.body.stmts[0], ReturnNode)
    assert func.body.stmts[0].value.op == BinOp.ADD


def test_if_else_for_and_loop_control_nodes():
    tree = parse(
        """
        for (let i: number = 0; i < 10; i++) {
          if (i == 5) {
            break;
          } else {
            continue;
          }
        }
        """
    )

    loop = tree.stmts[0]

    assert isinstance(loop, ForNode)
    assert isinstance(loop.init, LetDeclNode)
    assert loop.cond.op == BinOp.LT
    assert isinstance(loop.next, IncDecNode)

    if_stmt = loop.body.stmts[0]
    assert isinstance(if_stmt, IfNode)
    assert if_stmt.cond.op == BinOp.EQ
    assert isinstance(if_stmt.then_stmt.stmts[0], BreakNode)
    assert isinstance(if_stmt.else_stmt.stmts[0], ContinueNode)


def test_assignment_and_printer_tree_shape():
    tree = parse(
        """
        let count: number = 0;
        count = count + 1;
        """
    )

    assign = tree.stmts[1]
    assert isinstance(assign, AssignNode)
    assert assign.var.name == "count"
    assert assign.value.op == BinOp.ADD

    assert AstPrinter().tree(tree) == [
        "...",
        "├ let",
        "│ └ count : number =",
        "│   └ 0",
        "└ =",
        "  ├ count",
        "  └ +",
        "    ├ count",
        "    └ 1",
    ]
