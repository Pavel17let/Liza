from pathlib import Path
from typing import TypeVar, Optional, Sequence, Any

from lark import Lark, Transformer, v_args, UnexpectedCharacters, UnexpectedInput

from .ast import *
from .errors import ParserException

grammar_path = Path(__file__).parent / 'parser.lark'
grammar = grammar_path.read_text()

T = TypeVar('T')


@v_args(meta=True)
class ASTBuilder(Transformer):
    def _process_meta(self, node: T, meta) -> T:
        node.row = getattr(meta, 'line', None)
        node.col = getattr(meta, 'column', None)
        return node

    # базовые узлы
    def ident(self, meta, children) -> IdentNode:
        name = str(children[0])
        result = IdentNode(name)
        return self._process_meta(result, meta)

    def lvalue(self, meta, children) -> IdentNode:
        return children[0]

    def literal(self, meta, children) -> LiteralNode:
        value = str(children[0])
        result = LiteralNode(value)
        return self._process_meta(result, meta)

    def type(self, meta, children) -> TypeNode:
        result = TypeNode(str(children[0]))
        return self._process_meta(result, meta)

    def block(self, meta, children) -> StmtListNode:
        child = children[0]
        return child if isinstance(child, StmtListNode) else StmtListNode(child)

    def empty_expr(self, meta, children) -> None:
        return None

    def call(self, meta, children) -> CallNode:
        name = children[0]
        params = children[1:]
        result = CallNode(name, params)
        return self._process_meta(result, meta)

    # let/const
    def let_binding(self, meta, children) -> LetBindingNode:
        name = children[0].name if hasattr(children[0], 'name') else str(children[0])
        type_ann = None
        init = None
        for child in children[1:]:
            if isinstance(child, TypeNode):
                type_ann = child
            else:
                init = child
        result = LetBindingNode(name, type_ann, init)
        return self._process_meta(result, meta)

    def let_decl(self, meta, children) -> LetDeclNode:
        bindings = self._flatten(children)
        result = LetDeclNode(bindings)
        return self._process_meta(result, meta)

    def const_binding(self, meta, children) -> ConstBindingNode:
        name = children[0].name if hasattr(children[0], 'name') else str(children[0])
        if len(children) == 2:
            type_ann = None
            init = children[1]
        else:
            type_ann = children[1]
            init = children[2]
        result = ConstBindingNode(name, type_ann, init)
        return self._process_meta(result, meta)

    def const_decl(self, meta, children) -> ConstDeclNode:
        bindings = self._flatten(children)
        result = ConstDeclNode(bindings)
        return self._process_meta(result, meta)

    # параметры и функции
    def func_param(self, meta, children) -> FuncParamNode:
        name = children[0].name if hasattr(children[0], 'name') else str(children[0])
        type_ann = children[1]
        result = FuncParamNode(name, type_ann)
        return self._process_meta(result, meta)

    def func(self, meta, children) -> FuncNode:
        name = children[0].name if hasattr(children[0], 'name') else str(children[0])
        params = []
        idx = 1
        while idx < len(children) and isinstance(children[idx], FuncParamNode):
            params.append(children[idx])
            idx += 1
        return_type = None
        if len(children) > idx and children[idx] is not None and isinstance(children[idx], TypeNode):
            return_type = children[idx]
            idx += 1
        body = children[idx] if len(children) > idx else StmtListNode()
        result = FuncNode(name, return_type, params, body)
        return self._process_meta(result, meta)

    # правила-обёртки
    def primary(self, meta, children):
        return children[0]

    def expr(self, meta, children):
        return children[0]

    def unary(self, meta, children):
        return children[0]

    def mult(self, meta, children):
        return children[0]

    def add(self, meta, children):
        return children[0]

    def compare(self, meta, children):
        return children[0]

    def equals(self, meta, children):
        return children[0]

    def logic_and(self, meta, children):
        return children[0]

    def logic_or(self, meta, children):
        return children[0]

    def stmt(self, meta, children):
        return children[0]

    def stmp_or_empty(self, meta, children):
        return children[0] if children else None

    def simple_stmt(self, meta, children):
        return children[0]

    # for
    def for_init(self, meta, children) -> Any:
        return self._stmt_or_stmt_list(children)

    def for_update(self, meta, children) -> Any:
        return self._stmt_or_stmt_list(children)

    def return_stmt(self, meta, children) -> ReturnNode:
        value = children[0] if children else None
        result = ReturnNode(value)
        return self._process_meta(result, meta)

    def break_stmt(self, meta, children) -> BreakNode:
        return self._process_meta(BreakNode(), meta)

    def continue_stmt(self, meta, children) -> ContinueNode:
        return self._process_meta(ContinueNode(), meta)

    def if_stmt(self, meta, children) -> IfNode:
        result = IfNode(*children)
        return self._process_meta(result, meta)

    def while_stmt(self, meta, children) -> WhileNode:
        result = WhileNode(*children)
        return self._process_meta(result, meta)

    def for_stmt(self, meta, children) -> ForNode:
        result = ForNode(*children)
        return self._process_meta(result, meta)

    def _flatten(self, children):
        flat = []
        for child in children:
            if isinstance(child, list):
                flat.extend(child)
            else:
                flat.append(child)
        return flat

    def _stmt_or_stmt_list(self, children):
        if not children:
            return None
        if len(children) == 1:
            return children[0]
        return StmtListNode(children)

    def __default__(self, data, children, meta) -> Any:
        if isinstance(data, str) and data.upper() == data:
            return data

        if data in ('prefix_dec', 'prefix_inc', 'suffix_dec', 'suffix_inc'):
            op = IncDecOp[data.upper()]
            return self._process_meta(IncDecNode(op, *children), meta)

        if data in ('plus', 'minus', 'not'):
            op = UnOp[data.upper()]
            return self._process_meta(UnOpNode(op, *children), meta)

        if data in ('mul', 'div', 'mod', 'add_op', 'sub',
                    'gt', 'ge', 'lt', 'le', 'eq', 'ne',
                    'logic_and_op', 'logic_or_op'):
            op_name = {
                'add_op': 'ADD',
                'logic_and_op': 'LOGIC_AND',
                'logic_or_op': 'LOGIC_OR',
            }.get(data, data.upper())
            op = BinOp[op_name]
            return self._process_meta(BinOpNode(op, *children), meta)

        class_name = ''.join(x.capitalize() for x in data.split('_')) + 'Node'
        try:
            cls = eval(class_name)
            node = cls(*children)
            return self._process_meta(node, meta)
        except NameError:
            return children[0] if children else None


def parse(program: str) -> StmtListNode:
    parser = Lark(grammar, start="start", propagate_positions=True)
    try:
        parse_tree = parser.parse(str(program))
    except UnexpectedInput as e:
        if isinstance(e, UnexpectedCharacters):
            allowed = (t.pattern.value or t.pattern.raw if t.pattern.type == 'str' else a
                       for a in e.allowed for t in parser.terminals if t.name == a)
            error_msg = f'Ожидалось {", ".join(allowed)}'
        else:
            expected = ', '.join(sorted(getattr(e, 'expected', [])))
            error_msg = f'Ожидалось {expected}' if expected else 'Ошибка разбора'
        if hasattr(e, 'get_context'):
            error_msg += f', получено:\n{e.get_context(program)}\n'
        raise ParserException(error_msg, row=e.line, col=e.column)

    ast_tree: StmtListNode = ASTBuilder().transform(parse_tree)
    ast_tree.program = True
    return ast_tree
