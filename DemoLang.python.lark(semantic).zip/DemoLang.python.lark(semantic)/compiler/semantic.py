from enum import Enum
from typing import Sequence

from . import visitor
from .ast import *
from .errors import SemanticException


class BaseType(Enum):
    VOID = 'void'
    INT = 'int'
    FLOAT = 'float'
    BOOL = 'bool'
    STR = 'string'

    def __str__(self):
        return self.value


VOID, INT, FLOAT, BOOL, STR = BaseType.VOID, BaseType.INT, BaseType.FLOAT, BaseType.BOOL, BaseType.STR


class TypeDesc:
    VOID: 'TypeDesc'
    INT: 'TypeDesc'
    FLOAT: 'TypeDesc'
    BOOL: 'TypeDesc'
    STR: 'TypeDesc'

    def __init__(self, base_type: BaseType = None,
                 return_type: 'TypeDesc' = None, params: Sequence['TypeDesc'] = None) -> None:
        self.base_type = base_type
        self.return_type = return_type
        self.params = params

    @property
    def func(self) -> bool:
        return self.return_type is not None

    @property
    def is_simple(self) -> bool:
        return not self.func

    def __eq__(self, other: 'TypeDesc'):
        if self.func != other.func:
            return False
        if not self.func:
            return self.base_type == other.base_type
        else:
            if self.return_type != other.return_type:
                return False
            if len(self.params) != len(other.params):
                return False
            for i in range(len(self.params)):
                if self.params[i] != other.params[i]:
                    return False
            return True

    @staticmethod
    def from_base_type(base_type_: BaseType) -> 'TypeDesc':
        return getattr(TypeDesc, base_type_.name)

    @staticmethod
    def from_str(str_decl: str) -> 'TypeDesc':
        aliases = {
            'number': 'int',
            'boolean': 'bool',
        }
        normalized = aliases.get(str_decl, str_decl)
        try:
            base_type_ = BaseType(normalized)
            return TypeDesc.from_base_type(base_type_)
        except ValueError:
            raise SemanticException(f'Неизвестный тип {str_decl}')

    def __str__(self) -> str:
        if not self.func:
            return str(self.base_type)
        else:
            res = str(self.return_type)
            res += ' ('
            for param in self.params:
                if res[-1] != '(':
                    res += ', '
                res += str(param)
            res += ')'
            return res


for base_type in BaseType:
    setattr(TypeDesc, base_type.name, TypeDesc(base_type))


class ScopeType(Enum):
    GLOBAL = 'global'
    GLOBAL_LOCAL = 'global.local'
    PARAM = 'param'
    LOCAL = 'local'

    def __str__(self):
        return self.value


class IdentDesc:
    def __init__(self, name: str, type_: TypeDesc, scope: ScopeType = ScopeType.GLOBAL, index: int = 0, is_const: bool = False) -> None:
        self.name = name
        self.type = type_
        self.scope = scope
        self.index = index
        self.built_in = False
        self.is_const = is_const

    def __str__(self) -> str:
        result = f'{self.type}, {self.scope}'
        if self.built_in:
            result += ', built-in'
        elif not self.type.func:
            result += f', {self.index}'
        if self.is_const:
            result += ', const'
        return result


class IdentScope:
    def __init__(self, parent: 'IdentScope' = None, func: IdentDesc | None = None, loop: StmtNode | None = None) -> None:
        self.idents: dict[str, IdentDesc] = {}
        self.func = func
        self.loop = loop
        self.parent = parent
        self.var_index = 0
        self.param_index = 0

    @property
    def is_global(self) -> bool:
        return self.parent is None

    @property
    def curr_global(self) -> 'IdentScope':
        curr = self
        while curr.parent:
            curr = curr.parent
        return curr

    @property
    def curr_func(self) -> 'IdentScope':
        curr = self
        while curr and not curr.func:
            curr = curr.parent
        return curr

    @property
    def curr_loop(self) -> 'IdentScope':
        curr = self
        while curr and not curr.loop:
            curr = curr.parent
        return curr

    def add_ident(self, ident: IdentDesc) -> IdentDesc:
        func_scope = self.curr_func
        global_scope = self.curr_global

        if ident.scope != ScopeType.PARAM:
            ident.scope = ScopeType.LOCAL if func_scope else \
                ScopeType.GLOBAL if self == global_scope else ScopeType.GLOBAL_LOCAL

        old_ident = self.get_ident(ident.name)
        if old_ident:
            error = False
            if ident.scope == ScopeType.PARAM:
                if old_ident.scope == ScopeType.PARAM:
                    error = True
            elif ident.scope == ScopeType.LOCAL:
                if old_ident.scope not in (ScopeType.GLOBAL, ScopeType.GLOBAL_LOCAL):
                    error = True
            else:
                error = True
            if error:
                raise SemanticException(f'Идентификатор {ident.name} уже объявлен')

        if not ident.type.func:
            if ident.scope == ScopeType.PARAM:
                ident.index = func_scope.param_index
                func_scope.param_index += 1
            else:
                ident_scope = func_scope if func_scope else global_scope
                ident.index = ident_scope.var_index
                ident_scope.var_index += 1

        self.idents[str(ident.name)] = ident
        return ident

    def get_ident(self, name: str) -> IdentDesc:
        scope = self
        ident = None
        while scope:
            ident = scope.idents.get(name)
            if ident:
                break
            scope = scope.parent
        return ident


TYPE_CONVERTIBILITY = {
    INT: (FLOAT, BOOL, STR),
    FLOAT: (STR,),
    BOOL: (STR,)
}


def can_type_convert_to(from_type: TypeDesc, to_type: TypeDesc) -> bool:
    if not from_type.is_simple or not to_type.is_simple:
        return False
    return from_type.base_type in TYPE_CONVERTIBILITY and to_type.base_type in TYPE_CONVERTIBILITY[from_type.base_type]


UN_OP_TYPE_COMPATIBILITY = {
    UnOp.NOT: {BOOL: BOOL},
    UnOp.PLUS: {INT: INT, FLOAT: FLOAT},
    UnOp.MINUS: {INT: INT, FLOAT: FLOAT}
}

BIN_OP_TYPE_COMPATIBILITY = {
    BinOp.ADD: {(INT, INT): INT, (FLOAT, FLOAT): FLOAT, (STR, STR): STR},
    BinOp.SUB: {(INT, INT): INT, (FLOAT, FLOAT): FLOAT},
    BinOp.MUL: {(INT, INT): INT, (FLOAT, FLOAT): FLOAT},
    BinOp.DIV: {(INT, INT): INT, (FLOAT, FLOAT): FLOAT},
    BinOp.MOD: {(INT, INT): INT, (FLOAT, FLOAT): FLOAT},
    BinOp.GT: {(INT, INT): BOOL, (FLOAT, FLOAT): BOOL, (STR, STR): BOOL},
    BinOp.LT: {(INT, INT): BOOL, (FLOAT, FLOAT): BOOL, (STR, STR): BOOL},
    BinOp.GE: {(INT, INT): BOOL, (FLOAT, FLOAT): BOOL, (STR, STR): BOOL},
    BinOp.LE: {(INT, INT): BOOL, (FLOAT, FLOAT): BOOL, (STR, STR): BOOL},
    BinOp.EQ: {(INT, INT): BOOL, (FLOAT, FLOAT): BOOL, (STR, STR): BOOL, (BOOL, BOOL): BOOL},
    BinOp.NE: {(INT, INT): BOOL, (FLOAT, FLOAT): BOOL, (STR, STR): BOOL, (BOOL, BOOL): BOOL},
    BinOp.BIT_AND: {(INT, INT): INT},
    BinOp.BIT_OR: {(INT, INT): INT},
    BinOp.LOGIC_AND: {(BOOL, BOOL): BOOL},
    BinOp.LOGIC_OR: {(BOOL, BOOL): BOOL},
}


def semantic_error(node: AstNode, message: str):
    raise SemanticException(message, node.row, node.col)


def type_convert(expr: ExprNode, type_: TypeDesc, except_node: AstNode = None,
                 comment: str = None) -> ExprNode:
    if expr.node_type is None:
        semantic_error(except_node or expr, 'Тип выражения не определен')

    if expr.node_type == type_:
        return expr

    if can_type_convert_to(expr.node_type, type_):
        node = TypeConvertNode(expr, type_)
        node.node_type = type_
        return node
    else:
        semantic_error(
            except_node or expr,
            f'Тип {expr.node_type}{f" ({comment})" if comment else ""} не конвертируется в {type_}'
        )


class SemanticChecker:
    @visitor.on('AstNode')
    def semantic_check(self, AstNode, scope: IdentScope):
        pass

    @visitor.when(LiteralNode)
    def semantic_check(self, node: LiteralNode, scope: IdentScope):
        if isinstance(node.value, bool):
            node.node_type = TypeDesc.BOOL
        elif isinstance(node.value, int):
            node.node_type = TypeDesc.INT
        elif isinstance(node.value, float):
            node.node_type = TypeDesc.FLOAT
        elif isinstance(node.value, str):
            node.node_type = TypeDesc.STR
        else:
            semantic_error(node, f'Неизвестный тип {type(node.value)} для {node.value}')

    @visitor.when(IdentNode)
    def semantic_check(self, node: IdentNode, scope: IdentScope):
        ident = scope.get_ident(node.name)
        if ident is None:
            semantic_error(node, f'Идентификатор {node.name} не найден')
        node.node_type = ident.type
        node.node_ident = ident

    @visitor.when(TypeNode)
    def semantic_check(self, node: TypeNode, scope: IdentScope):
        try:
            node.type = TypeDesc.from_str(node.desc)
        except SemanticException as e:
            semantic_error(node, e.message)

    @visitor.when(IncDecNode)
    def semantic_check(self, node: IncDecNode, scope: IdentScope):
        node.var.semantic_check(self, scope)
        if not node.var.node_type.is_simple or node.var.node_type.base_type != INT or not node.var.node_ident:
            semantic_error(node, f'Оператор {node.op} можно применить только к переменным целого типа')
        node.node_type = node.var.node_type

    @visitor.when(UnOpNode)
    def semantic_check(self, node: UnOpNode, scope: IdentScope):
        node.arg.semantic_check(self, scope)

        if node.arg.node_type.is_simple:
            compatibility = UN_OP_TYPE_COMPATIBILITY[node.op]
            arg_type = node.arg.node_type.base_type
            if arg_type in compatibility:
                node.node_type = TypeDesc.from_base_type(compatibility[arg_type])
                return

            if node.arg.node_type.base_type in TYPE_CONVERTIBILITY:
                for arg_type in TYPE_CONVERTIBILITY[node.arg.node_type.base_type]:
                    if arg_type in compatibility:
                        node.arg = type_convert(node.arg, TypeDesc.from_base_type(arg_type))
                        node.node_type = TypeDesc.from_base_type(compatibility[arg_type])
                        return

        semantic_error(node, f'Оператор {node.op} не применим к типу {node.arg.node_type}')

    @visitor.when(BinOpNode)
    def semantic_check(self, node: BinOpNode, scope: IdentScope):
        node.arg1.semantic_check(self, scope)
        node.arg2.semantic_check(self, scope)

        if node.arg1.node_type.is_simple or node.arg2.node_type.is_simple:
            compatibility = BIN_OP_TYPE_COMPATIBILITY[node.op]
            args_types = (node.arg1.node_type.base_type, node.arg2.node_type.base_type)
            if args_types in compatibility:
                node.node_type = TypeDesc.from_base_type(compatibility[args_types])
                return

            if node.arg2.node_type.base_type in TYPE_CONVERTIBILITY:
                for arg2_type in TYPE_CONVERTIBILITY[node.arg2.node_type.base_type]:
                    args_types = (node.arg1.node_type.base_type, arg2_type)
                    if args_types in compatibility:
                        node.arg2 = type_convert(node.arg2, TypeDesc.from_base_type(arg2_type))
                        node.node_type = TypeDesc.from_base_type(compatibility[args_types])
                        return
            if node.arg1.node_type.base_type in TYPE_CONVERTIBILITY:
                for arg1_type in TYPE_CONVERTIBILITY[node.arg1.node_type.base_type]:
                    args_types = (arg1_type, node.arg2.node_type.base_type)
                    if args_types in compatibility:
                        node.arg1 = type_convert(node.arg1, TypeDesc.from_base_type(arg1_type))
                        node.node_type = TypeDesc.from_base_type(compatibility[args_types])
                        return

        semantic_error(node, f'Оператор {node.op} не применим к типам ({node.arg1.node_type}, {node.arg2.node_type})')

    @visitor.when(CallNode)
    def semantic_check(self, node: CallNode, scope: IdentScope):
        func = scope.get_ident(node.name.name)
        if func is None:
            semantic_error(node, f'Функция {node.name.name} не найдена')
        if not func.type.func:
            semantic_error(node, f'Идентификатор {func.name} не является функцией')

        params = []
        error = False
        decl_params_str = fact_params_str = ''

        if func.built_in and func.name == 'print':
            if len(node.params) not in (1, 2):
                semantic_error(node, f'Кол-во аргументов {func.name} не совпадает (ожидалось 1 или 2, передано {len(node.params)})')
            for param in node.params:
                param.semantic_check(self, scope)
                if len(decl_params_str) > 0:
                    decl_params_str += ', '
                decl_params_str += 'string'
                if len(fact_params_str) > 0:
                    fact_params_str += ', '
                fact_params_str += str(param.node_type)
                try:
                    params.append(type_convert(param, TypeDesc.STR))
                except SemanticException:
                    error = True
        else:
            if len(func.type.params) != len(node.params):
                semantic_error(node, f'Кол-во аргументов {func.name} не совпадает (ожидалось {len(func.type.params)}, передано {len(node.params)})')
            for i in range(len(node.params)):
                param: ExprNode = node.params[i]
                param.semantic_check(self, scope)
                if len(decl_params_str) > 0:
                    decl_params_str += ', '
                decl_params_str += str(func.type.params[i])
                if len(fact_params_str) > 0:
                    fact_params_str += ', '
                fact_params_str += str(param.node_type)
                try:
                    params.append(type_convert(param, func.type.params[i]))
                except SemanticException:
                    error = True

        if error:
            semantic_error(node, f'Фактические типы ({fact_params_str}) аргументов функции {func.name} не совпадают с формальными ({decl_params_str}) и не приводимы')
        else:
            node.params = tuple(params)
            node.name.node_type = func.type
            node.name.node_ident = func
            node.node_type = func.type.return_type

    @visitor.when(AssignNode)
    def semantic_check(self, node: AssignNode, scope: IdentScope):
        node.var.semantic_check(self, scope)
        if isinstance(node.var, IdentNode) and node.var.node_ident and node.var.node_ident.is_const:
            semantic_error(node, f'Невозможно присвоить значение константе {node.var.name}')
        node.value.semantic_check(self, scope)
        node.value = type_convert(node.value, node.var.node_type, node.value, 'присваиваемое значение')
        node.node_type = node.var.node_type

    @visitor.when(LetDeclNode)
    def semantic_check(self, node: LetDeclNode, scope: IdentScope):
        for binding in node.bindings:
            binding.semantic_check(self, scope)

    @visitor.when(VarDeclNode)
    def semantic_check(self, node: VarDeclNode, scope: IdentScope):
        for binding in node.bindings:
            binding.semantic_check(self, scope)

    @visitor.when(LetBindingNode)
    def semantic_check(self, node: LetBindingNode, scope: IdentScope):
        if node.type_ann:
            node.type_ann.semantic_check(self, scope)
            var_type = node.type_ann.type
        else:
            var_type = None
        if node.init:
            node.init.semantic_check(self, scope)
            if var_type is None:
                var_type = node.init.node_type
            else:
                node.init = type_convert(node.init, var_type, node.init, 'инициализатор')

        if var_type is None:
            semantic_error(node, f'Не удалось определить тип переменной {node.name} (нет аннотации и инициализатора)')

        ident = IdentDesc(node.name, var_type, is_const=False)
        try:
            scope.add_ident(ident)
        except SemanticException as e:
            semantic_error(node, e.message)

        node.node_type = TypeDesc.VOID

    @visitor.when(ConstDeclNode)
    def semantic_check(self, node: ConstDeclNode, scope: IdentScope):
        for binding in node.bindings:
            binding.semantic_check(self, scope)

    @visitor.when(ConstBindingNode)
    def semantic_check(self, node: ConstBindingNode, scope: IdentScope):
        if node.init is None:
            semantic_error(node, f'Константа {node.name} должна быть инициализирована')

        if node.type_ann:
            node.type_ann.semantic_check(self, scope)
            var_type = node.type_ann.type
        else:
            var_type = None

        node.init.semantic_check(self, scope)
        if var_type is None:
            var_type = node.init.node_type
        else:
            node.init = type_convert(node.init, var_type, node.init, 'инициализатор константы')

        ident = IdentDesc(node.name, var_type, is_const=True)
        try:
            scope.add_ident(ident)
        except SemanticException as e:
            semantic_error(node, e.message)

        node.node_type = TypeDesc.VOID

    @visitor.when(FuncParamNode)
    def semantic_check(self, node: FuncParamNode, scope: IdentScope):
        node.type_ann.semantic_check(self, scope)
        ident = IdentDesc(node.name, node.type_ann.type, ScopeType.PARAM)
        try:
            scope.add_ident(ident)
        except SemanticException as e:
            semantic_error(node, e.message)

    @visitor.when(FuncNode)
    def semantic_check(self, node: FuncNode, scope: IdentScope):
        # Нормализация параметров (если вдруг пришли TypeNode вместо FuncParamNode)
        normalized_params = []
        for i, p in enumerate(node.params):
            if isinstance(p, TypeNode):
                normalized_params.append(FuncParamNode(f"_param_{i}", p))
            else:
                normalized_params.append(p)
        node.params = normalized_params

        if scope.curr_func:
            semantic_error(node, f'Объявление функции ({node.name}) внутри другой функции не поддерживается')

        if node.return_type:
            node.return_type.semantic_check(self, scope)
            ret_type = node.return_type.type
        else:
            ret_type = TypeDesc.VOID

        func_scope = IdentScope(scope, func=True)
        param_types = []
        for param in node.params:
            param.semantic_check(self, func_scope)
            param_types.append(param.type_ann.type)

        func_type = TypeDesc(return_type=ret_type, params=tuple(param_types))
        func_ident = IdentDesc(node.name, func_type, scope=ScopeType.GLOBAL)
        func_scope.func = func_ident

        try:
            scope.curr_global.add_ident(func_ident)
        except SemanticException as e:
            semantic_error(node, e.message)

        node.body.semantic_check(self, func_scope)
        node.node_type = TypeDesc.VOID

    @visitor.when(ReturnNode)
    def semantic_check(self, node: ReturnNode, scope: IdentScope):
        func_scope = scope.curr_func
        if func_scope is None:
            semantic_error(node, 'Оператор return может использоваться только внутри функции')

        expected_type = func_scope.func.type.return_type
        if node.value is None:
            if expected_type != TypeDesc.VOID:
                semantic_error(node, f'Функция должна возвращать {expected_type}, а не void')
        else:
            node.value.semantic_check(self, scope)
            node.value = type_convert(node.value, expected_type, node.value, 'возвращаемое значение')
        node.node_type = TypeDesc.VOID

    @visitor.when(IfNode)
    def semantic_check(self, node: IfNode, scope: IdentScope):
        node.cond.semantic_check(self, scope)
        node.cond = type_convert(node.cond, TypeDesc.BOOL, None, 'условие')
        node.then_stmt.semantic_check(self, IdentScope(scope))
        if node.else_stmt:
            node.else_stmt.semantic_check(self, IdentScope(scope))
        node.node_type = TypeDesc.VOID

    @visitor.when(WhileNode)
    def semantic_check(self, node: WhileNode, scope: IdentScope):
        node.cond.semantic_check(self, scope)
        node.cond = type_convert(node.cond, TypeDesc.BOOL, None, 'условие')
        node.body.semantic_check(self, IdentScope(scope, loop=node))
        node.node_type = TypeDesc.VOID

    @visitor.when(ForNode)
    def semantic_check(self, node: ForNode, scope: IdentScope):
        loop_scope = IdentScope(scope)
        if node.init:
            node.init.semantic_check(self, loop_scope)
        if node.cond:
            node.cond.semantic_check(self, loop_scope)
            node.cond = type_convert(node.cond, TypeDesc.BOOL, None, 'условие')
        else:
            node.cond = LiteralNode('true')
            node.cond.semantic_check(self, loop_scope)
        if node.next:
            node.next.semantic_check(self, loop_scope)
        node.body.semantic_check(self, IdentScope(loop_scope, loop=node))
        node.node_type = TypeDesc.VOID

    @visitor.when(BreakNode)
    def semantic_check(self, node: BreakNode, scope: IdentScope):
        if scope.curr_loop is None:
            semantic_error(node, 'Оператор break может использоваться только внутри цикла')
        node.node_type = TypeDesc.VOID

    @visitor.when(ContinueNode)
    def semantic_check(self, node: ContinueNode, scope: IdentScope):
        if scope.curr_loop is None:
            semantic_error(node, 'Оператор continue может использоваться только внутри цикла')
        node.node_type = TypeDesc.VOID

    @visitor.when(StmtListNode)
    def semantic_check(self, node: StmtListNode, scope: IdentScope):
        if not node.program:
            scope = IdentScope(scope)
        for stmt in node.stmts:
            stmt.semantic_check(self, scope)
        node.node_type = TypeDesc.VOID


BUILT_IN_OBJECTS = '''
function read(): string { }
function print(p0: string) { }
function println(p0: string) { }
function to_int(p0: string): int { }
function to_float(p0: string): float { }
'''


def prepare_global_scope() -> IdentScope:
    from .parser import parse
    prog = parse(BUILT_IN_OBJECTS)
    checker = SemanticChecker()
    scope = IdentScope()
    checker.semantic_check(prog, scope)
    for name, ident in scope.idents.items():
        ident.built_in = True
    scope.var_index = 0
    return scope


def semantic_check(program: AstNode) -> None:
    checker = SemanticChecker()
    scope = prepare_global_scope()
    checker.semantic_check(program, scope)
