import os
import sys
from typing import TextIO, Sequence

from . import visitor
from .ast import *


class AstPrinter:
    @visitor.on('AstNode')
    def view_node(self, AstNode):
        pass

    @visitor.when(AstNode)
    def view_node(self, node: AstNode) -> tuple[str, Sequence[AstNode] | None]:
        return str(node), node.children

    @visitor.when(LiteralNode)
    def view_node(self, node: LiteralNode) -> tuple[str, Sequence[AstNode]]:
        return node.literal, ()

    @visitor.when(IdentNode)
    def view_node(self, node: IdentNode) -> tuple[str, Sequence[AstNode]]:
        return node.name, ()

    @visitor.when(TypeNode)
    def view_node(self, node: TypeNode) -> tuple[str, Sequence[AstNode]]:
        return node.desc, ()

    @visitor.when(AssignNode)
    def view_node(self, node: AssignNode) -> tuple[str, Sequence[ExprNode]]:
        return '=', (node.var, node.value)

    @visitor.when(IncDecNode)
    def view_node(self, node: IncDecNode) -> tuple[str, Sequence[ExprNode]]:
        return str(node.op), (node.var,)

    @visitor.when(UnOpNode)
    def view_node(self, node: UnOpNode) -> tuple[str, Sequence[ExprNode]]:
        return str(node.op), (node.arg,)

    @visitor.when(BinOpNode)
    def view_node(self, node: BinOpNode) -> tuple[str, Sequence[ExprNode]]:
        return str(node.op), (node.arg1, node.arg2)

    @visitor.when(LetDeclNode)
    def view_node(self, node: LetDeclNode) -> tuple[str, Sequence[LetBindingNode]]:
        return 'let', node.bindings

    @visitor.when(ConstDeclNode)
    def view_node(self, node: ConstDeclNode) -> tuple[str, Sequence[ConstBindingNode]]:
        return 'const', node.bindings

    @visitor.when(LetBindingNode)
    def view_node(self, node: LetBindingNode) -> tuple[str, Sequence[AstNode]]:
        parts = [str(node.name)]
        if node.type_ann:
            parts.append(f': {node.type_ann.desc}')
        children = []
        if node.init:
            parts.append('=')
            children.append(node.init)
        return ' '.join(parts), children

    @visitor.when(ConstBindingNode)
    def view_node(self, node: ConstBindingNode) -> tuple[str, Sequence[AstNode]]:
        parts = [str(node.name)]
        if node.type_ann:
            parts.append(f': {node.type_ann.desc}')
        parts.append('=')
        return ' '.join(parts), (node.init,)

    @visitor.when(FuncParamNode)
    def view_node(self, node: FuncParamNode) -> str:
        return f'{node.name}: {node.type_ann.desc}'

    @visitor.when(FuncNode)
    def view_node(self, node: FuncNode) -> tuple[str, Sequence[AstNode]]:
        params = ', '.join(f'{p.name}: {p.type_ann.desc}' for p in node.params)
        if node.return_type:
            ret = f': {node.return_type.desc}'
        else:
            ret = ''
        return f'function {node.name}({params}){ret}', (node.body,)

    @visitor.when(CallNode)
    def view_node(self, node: CallNode) -> tuple[str, Sequence[ExprNode]]:
        return f'{node.name}()', node.params

    @visitor.when(IfNode)
    def view_node(self, node: IfNode) -> tuple[str, Sequence[AstNode]]:
        if node.else_stmt:
            return 'if', (node.cond, node.then_stmt, node.else_stmt)
        return 'if', (node.cond, node.then_stmt)

    @visitor.when(WhileNode)
    def view_node(self, node: WhileNode) -> tuple[str, Sequence[AstNode]]:
        return 'while', (node.cond, node.body)

    @visitor.when(ForNode)
    def view_node(self, node: ForNode) -> tuple[str, Sequence[AstNode]]:
        return 'for', (node.init, node.cond, node.next, node.body)

    @visitor.when(ReturnNode)
    def view_node(self, node: ReturnNode) -> tuple[str, Sequence[AstNode] | None]:
        if node.value:
            return 'return', (node.value,)
        return 'return', ()

    @visitor.when(BreakNode)
    def view_node(self, node: BreakNode) -> str:
        return 'break'

    @visitor.when(ContinueNode)
    def view_node(self, node: ContinueNode) -> str:
        return 'continue'

    @visitor.when(StmtListNode)
    def view_node(self, node: StmtListNode) -> tuple[str, Sequence[StmtNode]]:
        return '...', node.stmts

    @visitor.when(TypeConvertNode)
    def view_node(self, node: TypeConvertNode) -> tuple[str, Sequence[ExprNode]]:
        return f'({node.type})', (node.value,)

    def tree(self, node: AstNode) -> list[str]:
        result = self.view_node(node)

        # нормализация
        if isinstance(result, tuple):
            name, children = result
        else:
            name, children = result, []

        # гарантируем список
        if children is None:
            children = []
        elif not isinstance(children, (list, tuple)):
            children = [children]

        # если не задали явно — берём из AST
        if not children:
            children = node.children

        semantic_info = ''
        if node.node_ident:
            semantic_info = str(node.node_ident)
        elif node.node_type:
            semantic_info = str(node.node_type)

        if name and semantic_info:
            name += f' : {semantic_info}'

        lines = [name]

        for i, child in enumerate(children):
            prefix_first = '└' if i == len(children) - 1 else '├'
            prefix_other = ' ' if i == len(children) - 1 else '│'

            subtree = self.tree(child)
            for j, line in enumerate(subtree):
                prefix = prefix_first if j == 0 else prefix_other
                lines.append(prefix + ' ' + line)

        return lines

    @staticmethod
    def print(node: AstNode, file: TextIO | None = None) -> None:
        printer = AstPrinter()
        print(*printer.tree(node), sep=os.linesep, file=(file or sys.stdout))
