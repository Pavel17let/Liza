from abc import ABC
from enum import Enum
from dataclasses import dataclass
from typing import Callable, Sequence, Iterable, Any, TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from semantic import TypeDesc, IdentScope, IdentDesc, SemanticChecker


def ast_dataclass(cls, **kwargs):
    return dataclass(cls, repr=False, **kwargs)


class AstNode(ABC):
    init_action: Callable[['AstNode'], None] = None
    row: int = None
    col: int = None
    node_type: 'TypeDesc' = None
    node_ident: 'IdentDesc' = None

    @property
    def children(self) -> Sequence['AstNode']:
        children: list[AstNode] = []
        for v in self.__dict__.values():
            if isinstance(v, AstNode):
                children.append(v)
            elif isinstance(v, Iterable) and not isinstance(v, (str, bytes)):
                for item in v:
                    if isinstance(item, AstNode):
                        children.append(item)
        return children

    def __str__(self) -> str:
        name = None
        for field in ('name', 'op', 'type', 'desc'):
            if hasattr(self, field):
                field_val = getattr(self, field)
                if not field_val:
                    continue
                if hasattr(field_val, 'value'):
                    name = str(getattr(field_val, 'value'))
                elif isinstance(field_val, AstNode):
                    name = str(field_val)
                else:
                    name = str(field_val)
        if not name:
            name = self.__class__.__name__
            if name.endswith('Node'):
                name = name[:-4].lower()
            if name.endswith('list'):
                name = f'{name[:-4]}[]'
        return name

    def semantic_check(self, checker: 'SemanticChecker', scope: 'IdentScope') -> None:
        checker.semantic_check(self, scope)


class ExprNode(AstNode, ABC):
    pass


class ValueNode(ExprNode, ABC):
    pass


class StmtNode(AstNode, ABC):
    pass


class LiteralNode(ExprNode):
    literal: str
    value: Any

    def __init__(self, literal: str) -> None:
        self.literal = str(literal)

        if literal == 'true':
            self.value = True
        elif literal == 'false':
            self.value = False
        elif literal.isdigit():
            self.value = int(literal)
        else:
            try:
                self.value = float(literal)
            except ValueError:
                self.value = literal.strip('"')


@ast_dataclass
class IdentNode(ExprNode):
    name: str


@ast_dataclass
class TypeNode(ExprNode):
    desc: str
    type: 'TypeDesc' = None


class IncDecOp(Enum):
    PREFIX_INC = '++()'
    PREFIX_DEC = '--()'
    SUFFIX_INC = '()++'
    SUFFIX_DEC = '()--'

    def __str__(self):
        return self.value


@ast_dataclass
class IncDecNode(AstNode):
    op: IncDecOp
    var: IdentNode


class UnOp(Enum):
    NOT = '!'
    PLUS = '+'
    MINUS = '-'

    def __str__(self):
        return self.value


@ast_dataclass
class UnOpNode(ExprNode):
    op: UnOp
    arg: ExprNode


class BinOp(Enum):
    ADD = '+'
    SUB = '-'
    MUL = '*'
    DIV = '/'
    MOD = '%'
    GT = '>'
    GE = '>='
    LT = '<'
    LE = '<='
    EQ = '=='
    NE = '!='
    BIT_AND = '&'
    BIT_OR = '|'
    LOGIC_OR = '||'
    LOGIC_AND = '&&'

    def __str__(self):
        return self.value


@ast_dataclass
class BinOpNode(ExprNode):
    op: BinOp
    arg1: ExprNode
    arg2: ExprNode


@ast_dataclass
class AssignNode(ExprNode, StmtNode):
    var: ExprNode
    value: ExprNode


@ast_dataclass
class LetBindingNode(AstNode):
    name: str
    type_ann: Optional[TypeNode]
    init: Optional[ExprNode]


@ast_dataclass
class LetDeclNode(StmtNode):
    bindings: Sequence[LetBindingNode]

    def __init__(self, bindings: Sequence[LetBindingNode]) -> None:
        self.bindings = bindings


@ast_dataclass
class ConstBindingNode(AstNode):
    name: str
    type_ann: Optional[TypeNode]
    init: ExprNode


@ast_dataclass
class ConstDeclNode(StmtNode):
    bindings: Sequence[ConstBindingNode]

    def __init__(self, bindings: Sequence[ConstBindingNode]) -> None:
        self.bindings = bindings


@ast_dataclass
class FuncParamNode(AstNode):
    name: str
    type_ann: TypeNode


@ast_dataclass
class FuncNode(StmtNode):
    name: str
    return_type: Optional[TypeNode]
    params: Sequence[FuncParamNode]
    body: StmtNode

    def __init__(self, name: str, return_type: Optional[TypeNode], params: Sequence[FuncParamNode], body: StmtNode) -> None:
        self.name = name
        self.return_type = return_type
        self.params = params
        self.body = body or StmtListNode()


@ast_dataclass
class CallNode(ExprNode, StmtNode):
    name: IdentNode
    params: Sequence[ExprNode]

    def __init__(self, name: IdentNode, *params: ExprNode) -> None:
        self.name = name
        self.params = params[0] if len(params) == 1 and isinstance(params[0], Sequence) else params


@ast_dataclass
class IfNode(StmtNode):
    cond: ExprNode
    then_stmt: StmtNode
    else_stmt: StmtNode = None

    def __init__(self, cond: ExprNode, then_stmt: StmtNode, else_stmt: StmtNode = None) -> None:
        self.cond = cond
        self.then_stmt = then_stmt or StmtListNode()
        self.else_stmt = else_stmt


@ast_dataclass
class WhileNode(StmtNode):
    cond: ExprNode
    body: StmtNode

    def __init__(self, cond: ExprNode, body: StmtNode) -> None:
        self.cond = cond
        self.body = body or StmtListNode()


@ast_dataclass
class ForNode(StmtNode):
    init: Optional[StmtNode]
    cond: Optional[ExprNode]
    next: Optional[StmtNode]
    body: StmtNode

    def __init__(self, init: Optional[StmtNode], cond: Optional[ExprNode], next_: Optional[StmtNode], body: StmtNode) -> None:
        self.init = init or StmtListNode()
        self.cond = cond or LiteralNode('true')
        self.next = next_ or StmtListNode()
        self.body = body or StmtListNode()


@ast_dataclass
class BreakNode(StmtNode):
    pass


@ast_dataclass
class ContinueNode(StmtNode):
    pass


@ast_dataclass
class ReturnNode(StmtNode):
    value: ExprNode = None


@ast_dataclass
class StmtListNode(StmtNode):
    stmts: Sequence[StmtNode]
    program: bool = False

    def __init__(self, *stmts: StmtNode) -> None:
        self.stmts = stmts[0] if len(stmts) == 1 and isinstance(stmts[0], Sequence) else stmts


@ast_dataclass
class TypeConvertNode(ExprNode):
    value: ExprNode
    type: 'TypeDesc'

    def __init__(self, expr: ExprNode, type_: 'TypeDesc') -> None:
        self.value = expr
        self.type = type_
        self.node_type = type_